package com.chaptor05;

public class ParseInt {
    public static void main(String[] args) {
        System.out.println(Integer.parseInt("-01301"));
    }
}
