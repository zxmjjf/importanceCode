package com.knowledge.myselfLamda;

public interface Lamdaparent extends MyselfInterface{
    static void funtion(){};
}
