package com.knowledge.myselfLamda;

/**
 * @FunctionalInterface
 * 此结构为函数式接口，也希望可以使用函数式接口替代实现此接口的实例
 * 该抽象方法的功能返回一个值: avalues - bvaluse
 */
public interface MyselfInterface {
    //int smallVaules(int avalues, int bvaluse, int a);
    int bigVaules(int avalues, int bvaluse);
}
